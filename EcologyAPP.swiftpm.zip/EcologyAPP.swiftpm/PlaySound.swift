//
//  PlaySound.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/13/22.
//

import Foundation
import AVFoundation

var player : AVAudioPlayer!

func playSoundError() {
    let url = Bundle.main.url(forResource: "ComputerError", withExtension: "mp3")
    guard url != nil else {
        return
    }
    do {
        player = try AVAudioPlayer(contentsOf: url!)
        player?.play()
    } catch {
        print("error")
    }
}

func playSoundSuccess() {
    let url = Bundle.main.url(forResource: "Success", withExtension: "wav")
    guard url != nil else {
        return
    }
    do {
        player = try AVAudioPlayer(contentsOf: url!)
        player?.play()
    } catch {
        print("error")
    }
}

func playSoundElectro() {
    let url = Bundle.main.url(forResource: "ElectroSound", withExtension: "mp3")
    guard url != nil else {
        return
    }
    do {
        player = try AVAudioPlayer(contentsOf: url!)
        player?.play()
    } catch {
        print("error")
    }
}

func playSoundVeter() {
    let url = Bundle.main.url(forResource: "VeterSound", withExtension: "mp3")
    guard url != nil else {
        return
    }
    do {
        player = try AVAudioPlayer(contentsOf: url!)
        player?.play()
    } catch {
        print("error")
    }
}

func playSoundWater() {
    let url = Bundle.main.url(forResource: "WaterSound", withExtension: "mp3")
    guard url != nil else {
        return
    }
    do {
        player = try AVAudioPlayer(contentsOf: url!)
        player?.play()
    } catch {
        print("error")
    }
}

func playSoundPickUp() {
    let url = Bundle.main.url(forResource: "itemPickUp", withExtension: "mp3")
    guard url != nil else {
        return
    }
    do {
        player = try AVAudioPlayer(contentsOf: url!)
        player?.play()
    } catch {
        print("error")
    }
}
