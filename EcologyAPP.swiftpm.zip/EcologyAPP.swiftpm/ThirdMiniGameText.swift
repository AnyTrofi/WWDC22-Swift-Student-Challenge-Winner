//
//  ThirdMiniGameText.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/11/22.
//

import SwiftUI

struct ThirdMiniGameText: View {
    
    @State var showSecondView = false
    
    var body: some View {
        VStack {
            ZStack {
                Color.white.opacity(0.5)
                Text("""
    Pollution of water bodies and oceans is fraught with several problems:
    The first is the pollution of the water itself, which a person consumes.
    The second is that the fish accumulate, during its life, harmful substances that have come from the outside and dissolved in the water. Reservoirs need to be protected from pollution and the cleanliness of coastal areas should also be monitored.
    """)
                .padding(.horizontal, 50)
                .padding(.vertical, 40)
                .font(Font.system(size: 84, weight: .bold))
                .foregroundColor(Color.black)
                .minimumScaleFactor(0.5)
            }
            .cornerRadius(16)
            .padding()
            Button {
                showSecondView = true
                playSoundSuccess()
            } label: {
                HStack{
                    Spacer()
                    Text("Next page").font(Font.system(size: 35)).padding()
                    Spacer()
                }.background(Color(hex: "79A7FF"))
            }
            .background(Color.blue)
            .foregroundColor(Color.white)
            .cornerRadius(22)
            .padding(.horizontal, 40)
            .padding(.bottom)
            .padding(.vertical, 20)
        }.fullScreenCover(isPresented: $showSecondView) {
            ThirdMiniGame()
        }.background(Image("ocean").resizable()).ignoresSafeArea(.all)
    }
}

struct ThirdMiniGameText_Previews: PreviewProvider {
    static var previews: some View {
        ThirdMiniGameText()
    }
}
