//
//  EndView.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/12/22.
//

import SwiftUI

struct EndView: View {
    var body: some View {
            VStack {
                ZStack {
                Color.white.opacity(0.5)
                Text("""
    Today you have learned many facts about the environment, it’s pollution and the different ways to protect it. Now you can apply this knowledge in life and make our planet even better!
    """)
                .padding(.horizontal, 50)
                .padding(.vertical, 40)
                .font(Font.system(size: 84, weight: .bold))
                .foregroundColor(Color.black)
                .minimumScaleFactor(0.5)
                }
                .cornerRadius(30)
                .padding()
            }
            .background(Image("Mount").resizable()).ignoresSafeArea(.all)
    }
}

struct EndView_Previews: PreviewProvider {
    static var previews: some View {
        EndView()
    }
}
