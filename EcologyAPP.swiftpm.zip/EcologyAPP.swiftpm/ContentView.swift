import SwiftUI

struct ContentView: View {
    @State var showSecondView = false
    var body: some View {
            VStack {
                ZStack {
                Color.white.opacity(0.7)
                Text("""
    Ecology - the science of the interaction of living organisms and the environment, or the state of the environment. Why is it important to take care of the environment? Now human health depends on the environment by 25-50%. And this figure is growing as the environment is polluted. An adult person inhales 7 to 8 liters of air per minute. This is about 11,000 liters of air per day. Liquid consumes 2-3 liters, and food - 1 kilogram. And accordingly, the more people pollute the environment, the more their health deteriorates. Therefore, now in 3 mini-games you will get acquainted with various ways to save the environment
    """)
                .font(Font.system(size: 84, weight: .bold))
                .foregroundColor(Color.black)
                .minimumScaleFactor(0.5)
                .padding(.horizontal, 50)
                .padding(.vertical, 40)
                }
                .cornerRadius(30)
                .padding()
                Spacer()
                Spacer()
                Button {
                    showSecondView = true
                    playSoundSuccess()
                } label: {
                    HStack{
                        Spacer()
                        Text("Next page").font(Font.system(size: 35)).padding()
                        Spacer()
                    }.background(Color.black)
                }
                .background(Color.blue)
                .foregroundColor(Color.white)
                .cornerRadius(22)
                .padding(.horizontal, 40)
                .padding(.bottom)
                .padding(.vertical, 20)
            }
            .background(Image("Mount").resizable())
            .fullScreenCover(isPresented: $showSecondView) {
                FirstMiniGameText()
            .ignoresSafeArea()
        }
    }
}
