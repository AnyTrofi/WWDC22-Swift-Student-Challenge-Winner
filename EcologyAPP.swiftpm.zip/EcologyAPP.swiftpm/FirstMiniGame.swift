//
//  FirstMiniGame.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/11/22.
//


import AVFoundation
import SwiftUI

struct FirstMiniGame: View {
    
    let pictures = [
        ("plasticTrash", "BluePlastic"),
        ("glassBrokenBottle", "RedGlass"),
        ("plasticBottle", "BluePlastic"),
        ("apple", "GreenOrganic"),
        ("paperBox", "YellowPaper"),
        ("PaperCoffee", "YellowPaper"),
        ("paper", "YellowPaper"),
        ("organcTrash", "GreenOrganic"),
        ("plasticBag", "BluePlastic"),
        ("glassBottle", "RedGlass"),
        ("0", "")
    ]
    
//    let trashContainers = ["BluePlastic", "GreenOrganic", "RedGlass", "YellowPaper"]
//    let invalidContainers = ["BluePlasticError", "GreenOrganicError", "RedGlassError", "YellowPaperError"]

    @State var currentTrash: Int = 0
    @State var Title: String = "Choose a suitable container"
    @State var showSecondView = false
    @State var nextButton = false
    @State var BlueBox: String = "BluePlastic"
    @State var GreenBox: String = "GreenOrganic"
    @State var RedBox: String = "RedGlass"
    @State var YellowBox: String = "YellowPaper"
    
    var body: some View {
        VStack {
            Image(pictures[currentTrash].0).resizable()
                .scaledToFit()
            
            Text(Title).padding(.horizontal, 50).padding(.vertical, 40).font(Font.system(size: 30, weight: .bold)).foregroundColor(Color.black)
            
            Spacer()
            
            HStack {
                
                Button {
                    if pictures[currentTrash].1 == BlueBox {
                        ChangeTrashImage()
                    } else {
                        BlueBox = "BluePlasticError"
                        playSoundError()
                        
                    }
                } label: {
                    Image(BlueBox)
                        .resizable()
                        .scaledToFit()
                }
                .padding()
                
                Button {
                    if pictures[currentTrash].1 == GreenBox {
                        ChangeTrashImage()
                    } else {
                        GreenBox = "GreenOrganicError"
                        playSoundError()
                    }
                } label: {
                    Image(GreenBox)
                        .resizable()
                        .scaledToFit()
                }
                .padding()
                
                Button {
                    if pictures[currentTrash].1 == RedBox {
                        ChangeTrashImage()
                    } else {
                        RedBox = "RedGlassError"
                        playSoundError()
                    }
                } label: {
                    Image(RedBox)
                        .resizable()
                        .scaledToFit()
                }
                .padding()
                
                Button {
                    if pictures[currentTrash].1 == YellowBox {
                        ChangeTrashImage()
                    } else {
                        YellowBox = "YellowPaperError"
                        playSoundError()
                    }
                } label: {
                    Image(YellowBox)
                        .resizable()
                        .scaledToFit()
                }
                .padding()
                }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
            
            if nextButton == true {
                Button {
                    showSecondView = true
                    playSoundSuccess()
                } label: {
                    HStack{
                        Spacer()
                        Text("Next page").font(Font.system(size: 35)).padding()
                        Spacer()
                    }.background(Color(hex: "FFD600")).foregroundColor(Color.black)
                }
                .background(Color(hex: "CFCFCF"))
                .cornerRadius(22)
                .padding(.horizontal, 40)
                .padding(.bottom)
                .padding(.vertical, 20)
            }
        }.fullScreenCover(isPresented: $showSecondView) {
            SecondMiniGameText()
        }.background(Color(hex: "CFCFCF"))
    }
    
    func ChangeTrashImage() {
        if currentTrash + 1 < pictures.count - 1 {
            currentTrash += 1
            BlueBox = "BluePlastic"
            GreenBox = "GreenOrganic"
            RedBox = "RedGlass"
            YellowBox = "YellowPaper"
            playSoundSuccess()
        } else {
            currentTrash += 1
            Title = "Good Job!!!"
            nextButton = true
        }
    }
}

struct FirstMiniGame_Previews: PreviewProvider {
    static var previews: some View {
        FirstMiniGame()
    }
}
