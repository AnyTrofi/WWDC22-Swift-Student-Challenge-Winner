//
//  FirstMiniGame.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/6/22.
//

import SwiftUI

struct FirstMiniGameText: View {
    @State var showSecondView = false
    var body: some View {
        VStack {
            ZStack {
                Color.white.opacity(0.5)
                Text("""
    Household waste decomposition period: Cardboard and newspaper about 3 months, glass more than 1000 years, plastic bottle 150-180 years. Therefore, in our time, it is especially important to dispose of garbage. But in order to effectively dispose of it, it must be sorted. A simple habit of people: sorting their garbage will help us save the environment and reduce pollution of the planet.
    """)
                .padding(.horizontal, 50)
                .padding(.vertical, 40)
                .font(Font.system(size: 84, weight: .bold))
                .foregroundColor(Color.black)
                .minimumScaleFactor(0.5)
            }
            .cornerRadius(16)
            .padding()
            Spacer()
            Button {
                showSecondView = true
                playSoundSuccess()
            } label: {
                HStack{
                    Spacer()
                    Text("Next page").font(Font.system(size: 35)).padding()
                    Spacer()
                }.background(Color(hex: "FFD600")).foregroundColor(Color.black)
            }
            .background(Color.blue)
            .foregroundColor(Color.white)
            .cornerRadius(22)
            .padding(.horizontal, 40)
            .padding(.bottom)
            .padding(.vertical, 20)
        }.fullScreenCover(isPresented: $showSecondView) {
            FirstMiniGame()
        }.background(Color(hex: "CFCFCF"))
    }
}


struct FirstMiniGameText_Previews: PreviewProvider {
    static var previews: some View {
        FirstMiniGameText()
    }
}
