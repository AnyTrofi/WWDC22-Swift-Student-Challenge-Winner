//
//  ThirdMiniGame.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/12/22.
//

import SwiftUI

struct ThirdMiniGame: View {
    
    @State var showSecondView = false
    @State var trash1 = 0
    @State var trash2 = 0
    @State var trash3 = 0
    @State var trash4 = 0
    @State var trash5 = 0
    @State var trash6 = 0
    @State var trash7 = 0
    @State var label = "Click on the trash to remove it"
    @State var nextButton = false
    
    var body: some View {
        VStack {
            ZStack {
                Color.white.opacity(0.5)
                Text(label)
                .padding(.horizontal, 20)
                .padding(.vertical, 20)
                .font(Font.system(size: 30, weight: .bold))
                .foregroundColor(Color.black)
            }.cornerRadius(16)
                .padding()
                .scaledToFit()
            HStack {
                VStack {
                    if trash1 == 0 {
                        Button {
                            trash1 = 1
                            checkAllTrash()
                            playSoundPickUp()
                        } label: {
                            Image("plasticTrash").resizable().scaledToFit()
                        }
                    } else {
                        Image("plasticTrash").resizable().scaledToFit().hidden()
                    }
                    Spacer()
                    HStack {
                        Image("paper").resizable().scaledToFit().hidden()
                        if trash2 == 0 {
                            Button {
                                trash2 = 1
                                checkAllTrash()
                                playSoundPickUp()
                            } label: {
                                Image("plasticBag").resizable().scaledToFit()
                            }
                        } else {
                            Image("plasticBag").resizable().scaledToFit().hidden()
                        }
                    }
                }
                Spacer()
                VStack {
                    Spacer ()
                    if trash3 == 0 {
                        Button {
                            trash3 = 1
                            checkAllTrash()
                            playSoundPickUp()
                        } label: {
                            Image("paper").resizable().scaledToFit()
                        }
                    } else {
                        Image("paper").resizable().scaledToFit().hidden()
                    }
                    Image("paper").resizable().scaledToFit().hidden()
                }
            }
            Spacer()
            HStack {
                VStack {
                    Image("paper").resizable().scaledToFit().hidden()
                    Spacer()
                    if trash4 == 0 {
                        Button {
                            trash4 = 1
                            checkAllTrash()
                            playSoundPickUp()
                        } label: {
                            Image("plasticBottle").resizable().scaledToFit()
                        }
                    } else {
                        Image("plasticBottle").resizable().scaledToFit().hidden()
                    }
                }
                Spacer()
                Image("paper").resizable().scaledToFit().hidden()
                VStack {
                    if trash5 == 0 {
                        Button {
                            trash5 = 1
                            checkAllTrash()
                            playSoundPickUp()
                        } label: {
                            Image("glassBrokenBottle").resizable().scaledToFit()
                        }
                    } else {
                        Image("glassBrokenBottle").resizable().scaledToFit().hidden()
                    }
                    Spacer()
                    Image("paper").resizable().scaledToFit().hidden()
                }
                Image("paper").resizable().scaledToFit().hidden()
            }
            Spacer()
            HStack {
                if trash6 == 0 {
                    Button {
                        trash6 = 1
                        checkAllTrash()
                        playSoundPickUp()
                    } label: {
                        Image("bigtrash1").resizable().scaledToFit()
                    }
                } else {
                    Image("bigtrash1").resizable().scaledToFit().hidden()
                }
                if trash7 == 0 {
                    Button {
                        trash7 = 1
                        checkAllTrash()
                        playSoundPickUp()
                    } label: {
                        Image("bigtrash2").resizable().scaledToFit()
                    }
                } else {
                    Image("bigtrash2").resizable().scaledToFit().hidden()
                }
            }
            if nextButton == true {
                Button {
                    showSecondView = true
                    playSoundSuccess()
                } label: {
                    HStack{
                        Spacer()
                        Text("Next page").font(Font.system(size: 35)).padding()
                        Spacer()
                    }.background(Color(hex: "79A7FF"))
                }
                .background(Color.blue)
                .foregroundColor(Color.white)
                .cornerRadius(22)
                .padding(.horizontal, 40)
                .padding(.bottom)
                .padding(.vertical, 20)
            }
        }.fullScreenCover(isPresented: $showSecondView) {
            EndView()
        }.background(Image("ocean").resizable()).ignoresSafeArea(.all)
    }
    
    func checkAllTrash() {
        if trash1 != 0 && trash2 != 0 && trash3 != 0 && trash4 != 0 && trash5 != 0 && trash6 != 0 && trash7 != 0 {
            label = "Good Job!!!"
            nextButton = true
        }
    }
}

struct ThirdMiniGame_Previews: PreviewProvider {
    static var previews: some View {
        ThirdMiniGame()
    }
}

