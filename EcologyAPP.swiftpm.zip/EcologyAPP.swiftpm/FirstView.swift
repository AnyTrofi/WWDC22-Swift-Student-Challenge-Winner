//
//  FirstView.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/12/22.
//

import SwiftUI

struct FirstView: View {
    @State var showSecondView = false
    var body: some View {
        ZStack {
            Image("Mount").resizable().cornerRadius(45)
            VStack {
                Spacer()
                StrokeText(text: "Save Ecology APP", width: 4, color: .white)
                    .foregroundColor(.black)
                    .font(.system(size: 12, weight: .bold))
                Spacer()
                Spacer()
                Spacer()
                    Text("TAP TO CONTINUE")
                        .font(Font.system(size: 25, weight: .heavy))
                        .opacity(0.9)
                        .padding()
                        .foregroundColor(Color.yellow)
                        .onTapGesture {
                            showSecondView = true
                            playSoundSuccess()
                        }
                }.cornerRadius(22).padding()
                Spacer()
        }
            .padding()
            .background(Color.black)
            .fullScreenCover(isPresented: $showSecondView) {
            ContentView()
                    .ignoresSafeArea(.all)
        }
    }
}

struct StrokeText: View {
    let text: String
    let width: CGFloat
    let color: Color

    var body: some View {
        ZStack{
            ZStack{
                Text(text).offset(x:  width, y:  width)
                Text(text).offset(x: -width, y: -width)
                Text(text).offset(x: -width, y:  width)
                Text(text).offset(x:  width, y: -width)
            }
            .foregroundColor(color)
            Text(text)
        }
        .padding(.horizontal, 50)
        .padding(.vertical, 40)
        .font(Font.system(size: 80, weight: .heavy))
        .foregroundColor(Color.yellow)
        .minimumScaleFactor(0.5)
    }
}

struct FirstView_Previews: PreviewProvider {
    static var previews: some View {
        FirstView()
    }
}
