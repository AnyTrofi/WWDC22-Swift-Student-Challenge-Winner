//
//  SecondMiniGameText.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/11/22.
//

import SwiftUI

struct SecondMiniGameText: View {
    
    @State var showSecondView = false
    
    var body: some View {
        VStack {
            ZStack {
                Color.white.opacity(0.5)
                Text("""
    Electricity generated from fuel combustion pollutes the environment. Which leads to global warming. Melting glaciers.
    It also pollutes the air we breathe. Our lungs, like a filter, absorb all these substances that are toxic to our body (oxides and dioxides of carbon, sulfur, nitrogen; hydrocarbons, sulfur derivatives, etc.)
    Alternative energy sources such as solar panels, wind turbines, hydroelectric power plants allow people to abandon energy sources that pollute the environment.
    """)
                .padding(.horizontal, 50)
                .padding(.vertical, 40)
                .font(Font.system(size: 84, weight: .bold))
                .foregroundColor(Color.black)
                .minimumScaleFactor(0.5)
            }
            .cornerRadius(16)
            .padding()

            Spacer()
            Button {
                showSecondView = true
                playSoundSuccess()
            } label: {
                HStack{
                    Spacer()
                    Text("Next page").font(Font.system(size: 35)).padding()
                    Spacer()
                }.background(Color.yellow)
            }
            .background(Color.blue)
            .foregroundColor(Color.white)
            .cornerRadius(22)
            .padding(.horizontal, 40)
            .padding(.bottom)
            .padding(.vertical, 20)
        }.fullScreenCover(isPresented: $showSecondView) {
            SecondMiniGame()
        }.background(Image("priroda").resizable()).ignoresSafeArea(.all)
    }
}

struct SecondMiniGameText_Previews: PreviewProvider {
    static var previews: some View {
        SecondMiniGameText()
    }
}
