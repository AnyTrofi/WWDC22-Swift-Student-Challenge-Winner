//
//  SecondMiniGame.swift
//  EcologyAPP
//
//  Created by Андрей Трофимов on 4/11/22.
//

import SwiftUI

struct ProgressBar: View {
    @Binding var value: Float
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle().frame(width: geometry.size.width , height: geometry.size.height)
                    .opacity(0.3)
                    .foregroundColor(Color(UIColor.systemYellow))
                
                Rectangle().frame(width: min(CGFloat(self.value)*geometry.size.width, geometry.size.width), height: geometry.size.height)
                    .foregroundColor(Color(UIColor.systemYellow))
                    .animation(.linear)
            }.cornerRadius(45.0)
        }
    }
}

struct SecondMiniGame: View {
    
    @State var progress1 : Float = 0.0
    @State var progress2 : Float = 0.0
    @State var progress3 : Float = 0.0
    @State var nextButton = false
    @State var showSecondView = false
    @State var Title: String = "Click on alternative energy source to fill electricity"
    
    var body: some View {
        VStack {
            ZStack {
                Text(Title)
                    .padding(.horizontal, 50)
                    .padding(.vertical, 40)
                    .font(Font.system(size: 24, weight: .bold))
                    .foregroundColor(Color.black)
                    .background(Color.white.opacity(0.5))
                    .cornerRadius(16)
            }
            Spacer()
            Spacer()
            HStack {
                    Button {
                        playSoundElectro()
                        progress1 += 0.25
                        checkProgress()
                    } label: {
                        Image("solarPanel")
                            .resizable()
                            .scaledToFit()
                            
                    }
                    ProgressBar(value: $progress1).frame(height: 20)
                if progress1 < 1.00 {
                    Image("houselightoff").resizable()
                        .scaledToFit()
                } else {
                    Image("houseligthon").resizable()
                        .scaledToFit()
                }
            }.padding()

            HStack {
                if progress2 < 1.00 {
                    Image("houselightoff").resizable()
                        .scaledToFit()
                } else {
                    Image("houseligthon").resizable()
                        .scaledToFit()
                }
                ProgressBar(value: $progress2).frame(height: 20)
                Button {
                    playSoundVeter()
                    progress2 += 0.25
                    checkProgress()
                } label: {
                    Image("vetriak")
                        .resizable()
                        .scaledToFit()
                }
            }.padding()
            HStack {
                Button {
                    playSoundWater()
                    progress3 += 0.25
                    checkProgress()
                } label: {
                    Image("waterPower")
                        .resizable()
                        .scaledToFit()
                        .padding()
                }
                ProgressBar(value: $progress3).frame(height: 20)
                if progress3 < 1.00 {
                    Image("houselightoff").resizable()
                        .scaledToFit()
                } else {
                    Image("houseligthon").resizable()
                        .scaledToFit()
                }
            }.padding()
            
            if nextButton == true {
                Button {
                    showSecondView = true
                    playSoundSuccess()
                } label: {
                    HStack{
                        Spacer()
                        Text("Next page").font(Font.system(size: 35)).padding()
                        Spacer()
                    }.background(Color(hex: "FFD600")).foregroundColor(Color.black)
                }
                .background(Color.black)
                .cornerRadius(22)
                .padding(.horizontal, 40)
                .padding(.bottom)
                .padding(.vertical, 20)
            }
            
        }.fullScreenCover(isPresented: $showSecondView) {
            ThirdMiniGameText()
        }.background(Image("priroda").resizable()).ignoresSafeArea()
    }
    
    func checkProgress() {
        if progress1 >= 1.0 && progress2 >= 1.0 && progress3 >= 1.0 {
            nextButton = true
            Title = "Good Job!!!"
        }
    }
}


struct SecondMiniGame_Previews: PreviewProvider {
    static var previews: some View {
        SecondMiniGame()
    }
}
